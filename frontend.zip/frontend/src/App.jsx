import React, { useState, useEffect, useRef } from "react";
import WalletConnect from "./components/walletConnect.jsx";
import CandlestickChart from "./components/candlestickchart.jsx";
import TradePanel from "./components/tradePanel.jsx";
import BotsPanel from "./components/bots.jsx";
import PortfolioPanel from "./components/portfolio.jsx";
import PositionsPanel from "./components/positions.jsx";
import "./styles/app.css";
import * as strategies from "./utils/strategies.js";

export default function App() {
  // --- app state ---
  const [account, setAccount] = useState(null);
  const [cashBalance, setCashBalance] = useState(null);
  const [positions, setPositions] = useState({});
  const [selectedAsset, setSelectedAsset] = useState("sBTC");
  const selectedAssetRef = useRef(selectedAsset);
  selectedAssetRef.current = selectedAsset;

  const [trades, setTrades] = useState([]);

  const [bots, setBots] = useState([
    {
      id: "preset-momentum",
      name: "Momentum Bot (Preset)",
      type: "momentum",
      params: { lookback: 20, threshold: 0.002, amount: 0.01 },
      enabled: false,
    },
  ]);
  const botsRef = useRef(bots);
  botsRef.current = bots;

  const [theme, setTheme] = useState("dark");
  const evalIntervalRef = useRef(null);

  // left nav panel open/closed
  const [leftOpen, setLeftOpen] = useState(true);

  // bottom positions panel open/closed
  const [bottomOpen, setBottomOpen] = useState(false);

  // ---- MISSING CONSTANTS ADDED HERE ----
  // Keep constants in sync with CSS (.left-panel width / closed transform / bottom heights)
  const BASE_LEFT = 18;
  const PANEL_OPEN_WIDTH = 360;
  const PANEL_CLOSED_WIDTH = 72;
  const HANDLE_OVERLAP = 16;
  // bottom sizes (for handle placement only)
  const BOTTOM_OPEN_HEIGHT = 320;
  const BOTTOM_CLOSED_HEIGHT = 56;
  // --------------------------------------

  // current market prices (polled) — include new assets with sane defaults
  const [currentPrices, setCurrentPrices] = useState({
    sBTC: null,
    sETH: null,
    SEL: 0.02,
    sGOLD: 1960,
    sEURUSD: 1.10,
    sNIFTY: 19500,
  });

  // toggle — overlay animation (no layout shift)
  const toggleLeft = () => {
    setLeftOpen((v) => !v);
    setTimeout(() => {
      try {
        window.dispatchEvent(new Event("resize"));
      } catch (e) {}
    }, 420);
  };

  const toggleBottom = () => {
    setBottomOpen((v) => !v);
    setTimeout(() => {
      try {
        window.dispatchEvent(new Event("resize"));
      } catch (e) {}
    }, 420);
  };

  // --- helpers & persistence (unchanged) ---
  useEffect(() => {
    try {
      const savedBots = localStorage.getItem("selina_bots");
      if (savedBots) setBots(JSON.parse(savedBots));

      const savedTrades = localStorage.getItem("selina_trades");
      if (savedTrades) setTrades(JSON.parse(savedTrades));

      const savedBalance = localStorage.getItem("selina_balance");
      if (savedBalance !== null) setCashBalance(Number(savedBalance));
      else setCashBalance((b) => (b == null ? 1000 : b));

      const savedPositions = localStorage.getItem("selina_positions");
      if (savedPositions) setPositions(JSON.parse(savedPositions));
    } catch (e) {
      console.warn("Failed to load saved state:", e);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("selina_bots", JSON.stringify(bots));
    } catch (e) {}
  }, [bots]);

  useEffect(() => {
    try {
      localStorage.setItem("selina_trades", JSON.stringify(trades));
    } catch (e) {}
  }, [trades]);

  useEffect(() => {
    try {
      if (cashBalance != null) localStorage.setItem("selina_balance", String(cashBalance));
    } catch (e) {}
  }, [cashBalance]);

  useEffect(() => {
    try {
      localStorage.setItem("selina_positions", JSON.stringify(positions));
    } catch (e) {}
  }, [positions]);

  useEffect(() => {
    botsRef.current = bots;
  }, [bots]);

  // --- price polling (1s) ---
  const fetchPrices = async () => {
    try {
      // We keep BTC/ETH real via Binance; other pairs use simulated defaults for now
      const symbols = ["BTCUSDT", "ETHUSDT"];
      const resArr = await Promise.all(
        symbols.map((s) =>
          fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${s}`).then((r) => r.json())
        )
      );
      const next = { ...currentPrices };
      resArr.forEach((r) => {
        if (r && r.symbol && r.price) {
          if (r.symbol === "BTCUSDT") next.sBTC = Number(parseFloat(r.price).toFixed(6));
          if (r.symbol === "ETHUSDT") next.sETH = Number(parseFloat(r.price).toFixed(6));
        }
      });

      // Ensure our simulated pairs stay present (won't be overwritten)
      next.sGOLD = next.sGOLD ?? 1960;
      next.sEURUSD = next.sEURUSD ?? 1.10;
      next.sNIFTY = next.sNIFTY ?? 19500;
      next.SEL = next.SEL ?? 0.02;

      setCurrentPrices(next);
    } catch (e) {
      // keep last known or sensible defaults
      setCurrentPrices((p) => ({
        ...p,
        SEL: p.SEL ?? 0.02,
        sBTC: p.sBTC ?? 20000,
        sETH: p.sETH ?? 1500,
        sGOLD: p.sGOLD ?? 1960,
        sEURUSD: p.sEURUSD ?? 1.10,
        sNIFTY: p.sNIFTY ?? 19500,
      }));
    }
  };

  useEffect(() => {
    fetchPrices();
    const id = setInterval(fetchPrices, 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --- bots runner, equity, trading core etc unchanged ---
  useEffect(() => {
    if (evalIntervalRef.current) {
      clearInterval(evalIntervalRef.current);
      evalIntervalRef.current = null;
    }

    const enabledCount = botsRef.current.filter((b) => b.enabled).length;
    if (enabledCount === 0) return;

    const intervalMs = 3000;
    evalIntervalRef.current = setInterval(() => {
      const enabled = botsRef.current.filter((b) => b.enabled);
      enabled.forEach((bot) => {
        const asset = selectedAssetRef.current || "sBTC";
        const lastPrice = currentPrices[asset] ?? (asset === "sBTC" ? 20000 : asset === "sETH" ? 1500 : 0.02);
        const series = new Array(60).fill(lastPrice).map((v, i) => v * (1 + (Math.sin((Date.now() / 1000 + i) / 10) * 0.001)));
        const signal = strategies.runStrategy(bot, series);
        const amount = typeof bot.params?.amount === "string" ? parseFloat(bot.params.amount) : bot.params?.amount ?? 0.001;
        const price = lastPrice;
        if (signal === 1) handleTrade("BUY", amount, price, { bot: bot.name, algo: bot.type });
        else if (signal === -1) handleTrade("SELL", amount, price, { bot: bot.name, algo: bot.type });
      });
    }, intervalMs);

    return () => {
      if (evalIntervalRef.current) {
        clearInterval(evalIntervalRef.current);
        evalIntervalRef.current = null;
      }
    };
  }, [bots, currentPrices]);

  const computeEquity = () => {
    let cash = typeof cashBalance === "number" ? cashBalance : 0;
    let total = cash;
    for (const assetKey of Object.keys(positions)) {
      const posArr = positions[assetKey] || [];
      const price = currentPrices[assetKey] ?? (assetKey === "sBTC" ? 20000 : assetKey === "sETH" ? 1500 : 0.02);
      posArr.forEach((pos) => {
        const notional = pos.amount * pos.entryPrice;
        const margin = notional / pos.leverage;
        let unrealized = 0;
        if (pos.side === "LONG") unrealized = (price - pos.entryPrice) * pos.amount;
        else unrealized = (pos.entryPrice - price) * pos.amount;
        total += margin + unrealized;
      });
    }
    return Number(total.toFixed(8));
  };

  const equity = computeEquity();

  const handleTrade = (type, amount, price, extra = {}) => {
    const amt = typeof amount === "string" ? parseFloat(amount) : amount;
    const marketPrice = price ?? currentPrices[selectedAsset] ?? (selectedAsset === "sBTC" ? 20000 : selectedAsset === "sETH" ? 1500 : 0.02);
    const p = typeof marketPrice === "string" ? parseFloat(marketPrice) : marketPrice;
    if (!amt || amt <= 0) {
      console.warn("Invalid trade amount", amount);
      return;
    }

    const leverage = 100;

    const notional = amt * p;
    const margin = notional / leverage;

    if (typeof cashBalance !== "number" || cashBalance < margin - 1e-12) {
      console.warn("Insufficient cash for margin", cashBalance, margin);
      alert("Insufficient demo cash to open position with 100x leverage");
      return;
    }

    const pos = {
      id: Date.now(),
      side: type === "BUY" ? "LONG" : "SHORT",
      amount: amt,
      entryPrice: Number(p.toFixed ? p.toFixed(8) : p),
      leverage,
      asset: selectedAsset,
      openedAt: new Date().toLocaleString(),
      openedAtTs: Date.now(),
      ...extra,
    };

    setCashBalance((prev) => Number(((prev || 0) - margin).toFixed(8)));

    setPositions((prev) => {
      const next = { ...(prev || {}) };
      next[selectedAsset] = (next[selectedAsset] || []).concat([pos]);
      return next;
    });

    const newTrade = {
      id: Date.now() + Math.floor(Math.random() * 1000),
      type,
      amount: Number(amt.toFixed ? amt.toFixed(8) : amt),
      price: Number(p?.toFixed ? p.toFixed(8) : p) || null,
      asset: selectedAsset,
      time: new Date().toLocaleString(),
      ts: Date.now(),
      leverage,
      ...extra,
    };

    setTrades((prev) => [newTrade, ...(prev || [])]);
  };

  const closePosition = (asset, positionId, closePrice) => {
    const price = closePrice ?? (currentPrices[asset] ?? (asset === "sBTC" ? 20000 : asset === "sETH" ? 1500 : 0.02));
    setPositions((prev) => {
      const next = { ...prev };
      const arr = (next[asset] || []).slice();
      const idx = arr.findIndex((p) => p.id === positionId);
      if (idx === -1) return prev;
      const pos = arr[idx];
      const notional = pos.amount * pos.entryPrice;
      const margin = notional / pos.leverage;
      let pnl = 0;
      if (pos.side === "LONG") pnl = (price - pos.entryPrice) * pos.amount;
      else pnl = (pos.entryPrice - price) * pos.amount;
      setCashBalance((prevCash) => Number(((prevCash || 0) + margin + pnl).toFixed(8)));
      arr.splice(idx, 1);
      next[asset] = arr;
      return next;
    });
    setTrades((prev) => [
      { id: Date.now() + Math.floor(Math.random() * 1000), type: "CLOSE", asset, price: closePrice, time: new Date().toLocaleString() },
      ...(prev || []),
    ]);
  };

  const clearHistory = () => {
    setTrades([]);
    try {
      localStorage.removeItem("selina_trades");
    } catch (e) {}
  };

  const addBot = (bot) => setBots((prev) => [{ ...bot, id: String(Date.now()) }, ...prev]);
  const updateBot = (id, patch) => setBots((prev) => prev.map((b) => (b.id === id ? { ...b, ...patch } : b)));
  const removeBot = (id) => setBots((prev) => prev.filter((b) => b.id !== id));

  // handle left-handle left position so it remains visible
  const handleLeft = leftOpen ? BASE_LEFT + PANEL_OPEN_WIDTH - HANDLE_OVERLAP : BASE_LEFT;

  return (
    <div className={`app ${theme === "dark" ? "theme-dark" : "theme-light"}`}>
      {/* Left fixed mirror panel (overlay; does not shift layout) */}
      <aside className={`left-panel ${leftOpen ? "open" : "closed"}`} aria-hidden={!leftOpen}>
        <div className="left-panel-inner">
          <div className="left-panel-header">
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <img src="/selina-logo.png" alt="Selina" className="left-logo" onError={(e) => (e.target.style.display = "none")} />
              <div>
                <div style={{ fontWeight: 800 }}>Selina</div>
                <div style={{ fontSize: 12, color: "var(--muted)" }}>Portfolio & Bots</div>
              </div>
            </div>

            <button
              className="left-panel-toggle"
              aria-label={leftOpen ? "Collapse panel" : "Open panel"}
              onClick={toggleLeft}
            >
              {leftOpen ? "⟨" : "⟩"}
            </button>
          </div>

          <div className="left-panel-body">
            <div style={{ padding: 10 }}>
              <PortfolioPanel positions={positions} currentPrices={currentPrices} />
            </div>

            <div style={{ padding: 10, borderTop: "1px solid rgba(255,255,255,0.03)" }}>
              <BotsPanel bots={bots} onAddBot={addBot} onUpdateBot={updateBot} onRemoveBot={removeBot} />
            </div>
          </div>
        </div>
      </aside>

      {/* Slim handle — clickable and always visible to reopen the left panel */}
      <div
        className={`left-handle ${leftOpen ? "open" : "closed"}`}
        role="button"
        tabIndex={0}
        aria-label={leftOpen ? "Collapse left panel" : "Open left panel"}
        onClick={toggleLeft}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") toggleLeft();
        }}
        style={{ left: handleLeft }}
      >
        <div className="left-handle-inner">{leftOpen ? "«" : "»"}</div>
      </div>

      {/* header / main / footer no longer shift left when panel toggles */}
      <header className="app-header">
        <div className="header-left">
          <img src="/selina-logo.png" alt="Selina" className="logo" onError={(e) => (e.target.style.display = "none")} />
          <div>
            <h1 className="app-title">Selina Synthetic Trading App</h1>
            <div className="subtitle">Demo Margin Trading · Synthetic Assets</div>
          </div>
        </div>

        <div className="header-right header-summary">
          <div className="account-summary">
            <div className="summary-item">
              <div className="summary-label">Cash</div>
              <div className="summary-value mono">{cashBalance != null ? cashBalance : "—"}</div>
            </div>
            <div className="summary-item">
              <div className="summary-label">Equity</div>
              <div className="summary-value mono">{equity != null ? equity : "—"}</div>
            </div>
          </div>

          <div style={{ marginLeft: 12 }}>
            <WalletConnect
              account={account}
              setAccount={setAccount}
              setBalance={(b) => {
                setCashBalance(typeof b === "string" ? Number(b) : b);
              }}
            />
          </div>
        </div>
      </header>

      <main className="app-main">
        <section className="panel chart-panel" aria-label="Chart panel">
          <div className="panel-header">
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <h2 className="panel-title">{selectedAsset}/Market Live Chart</h2>

              <select
                value={selectedAsset}
                onChange={(e) => setSelectedAsset(e.target.value)}
                className="input asset-select"
                title="Select asset"
              >
                <option value="SEL">SEL (Selina)</option>
                <option value="sBTC">sBTC (Synthetic BTC)</option>
                <option value="sETH">sETH (Synthetic ETH)</option>
                <option value="sGOLD">sGOLD (Gold)</option>
                <option value="sEURUSD">sEURUSD (EUR / USD)</option>
                <option value="sNIFTY">sNIFTY (Nifty 50)</option>
              </select>
            </div>

            <div className="panel-actions">
              <button className="btn small" onClick={() => alert("Chart controls not implemented")}>
                Chart Controls
              </button>
            </div>
          </div>

          <div className="panel-body">
            <CandlestickChart asset={selectedAsset} trades={trades} />
          </div>
        </section>

        <aside className="panel side-panel" aria-label="Trade panel">
          <div className="panel-header">
            <h3 className="panel-title">Trade Panel</h3>
            <div className="small-muted">
              Wallet: {account ? <span className="mono">{account === "demo" ? "Demo Account" : `${String(account).slice(0, 6)}...${String(account).slice(-4)}`}</span> : <span className="muted">Not connected</span>}
            </div>
          </div>

          <div className="panel-body">
            <TradePanel asset={selectedAsset} balanceCash={cashBalance} equity={equity} onTrade={(t, a, p, e) => handleTrade(t, a, p, e)} />

            <div style={{ marginTop: 12 }}>
              <div className="small-muted">Cash: {cashBalance ?? "—"}</div>
              <div className="small-muted">Equity: {equity ?? "—"}</div>
              <div className="small-muted">Open positions: {(positions[selectedAsset] || []).length}</div>
            </div>
          </div>
        </aside>
      </main>

      <div className="history-and-bots" style={{ padding: "0 18px 18px" }}>
        <section className="panel history-panel" style={{ flex: 1 }}>
          <div className="panel-header">
            <h3 className="panel-title">Trade History</h3>
            <div style={{ display: "flex", gap: 8 }}>
              <button
                className="btn small ghost"
                onClick={() => {
                  navigator.clipboard?.writeText(JSON.stringify(trades, null, 2));
                  alert("Copied history to clipboard");
                }}
              >
                Export
              </button>
              <button className="btn small danger" onClick={clearHistory}>
                Clear
              </button>
            </div>
          </div>

          <div className="panel-body">
            {trades.length === 0 ? (
              <div className="no-trades">No trades yet. Execute a trade to populate history.</div>
            ) : (
              <div className="history-table-wrap">
                <table className="history-table">
                  <thead>
                    <tr>
                      <th>Type</th>
                      <th>Asset</th>
                      <th>Amount</th>
                      <th>Price</th>
                      <th>Leverage</th>
                      <th>Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {trades.map((t) => (
                      <tr key={t.id}>
                        <td className={`trade-type ${t.type}`}>{t.type}</td>
                        <td>{t.asset}</td>
                        <td className="mono">{t.amount}</td>
                        <td>{t.price ? `$${t.price}` : "—"}</td>
                        <td>{t.leverage ? `${t.leverage}x` : "—"}</td>
                        <td className="mono small-muted">{t.time}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Bottom overlay positions panel (big rectangular) */}
      <aside className={`bottom-panel ${bottomOpen ? "open" : "closed"}`} aria-hidden={!bottomOpen}>
        <div className="bottom-panel-inner">
          <div className="bottom-panel-header">
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <div style={{ fontWeight: 800 }}>Open Positions</div>
              <div style={{ fontSize: 12, color: "var(--muted)" }}>{Object.keys(positions).reduce((s, a) => s + (positions[a] || []).length, 0)} total</div>
            </div>

            <button
              className="bottom-panel-toggle"
              aria-label={bottomOpen ? "Collapse positions" : "Open positions"}
              onClick={toggleBottom}
            >
              {bottomOpen ? "↓" : "↑"}
            </button>
          </div>

          <div className="bottom-panel-body">
            <div style={{ padding: 12 }}>
              <PositionsPanel positions={positions} currentPrices={currentPrices} onClosePosition={closePosition} />
            </div>
          </div>
        </div>
      </aside>

      {/* Bottom handle (centered) — always visible small rail to open/close bottom panel */}
      <div
        className={`bottom-handle ${bottomOpen ? "open" : "closed"}`}
        role="button"
        tabIndex={0}
        aria-label={bottomOpen ? "Collapse positions panel" : "Open positions panel"}
        onClick={toggleBottom}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") toggleBottom();
        }}
      >
        <div className="bottom-handle-inner">{bottomOpen ? "▼" : "▲"}</div>
      </div>

      <footer className="app-footer" style={{ padding: "12px 18px" }}>
        <div>
          &copy; {new Date().getFullYear()} Selina Synthetic Trading App — Contract:
          <code className="mono" style={{ marginLeft: 8 }}>
            0xab69946664AAF7D1164FA2fcf4a2429e062f2178
          </code>
        </div>
      </footer>
    </div>
  );
}
