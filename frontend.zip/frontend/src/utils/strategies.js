// small, dependency-free indicator helpers and strategy evaluators
export function sma(values, period) {
  if (!values || values.length < period) return null;
  const slice = values.slice(-period);
  return slice.reduce((s, v) => s + v, 0) / period;
}

export function ema(values, period) {
  if (!values || values.length < period) return null;
  const k = 2 / (period + 1);
  let emaPrev = sma(values.slice(0, period), period);
  for (let i = period; i < values.length; i++) {
    emaPrev = values[i] * k + emaPrev * (1 - k);
  }
  return emaPrev;
}

export function rsi(values, period = 14) {
  if (!values || values.length <= period) return null;
  let gains = 0, losses = 0;
  for (let i = values.length - period; i < values.length; i++) {
    const diff = values[i] - values[i - 1];
    if (diff > 0) gains += diff; else losses += Math.abs(diff);
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

// Strategy evaluators return -1 (sell), 0 (hold), 1 (buy)
export function emaCrossoverSignal(prices, params = { fast: 9, slow: 20 }) {
  const fast = ema(prices, params.fast);
  const slow = ema(prices, params.slow);
  if (fast == null || slow == null) return 0;
  if (fast > slow * (1 + (params.threshold || 0))) return 1;
  if (fast < slow * (1 - (params.threshold || 0))) return -1;
  return 0;
}

export function zscoreMeanReversionSignal(prices, params = { lookback: 50, z: 1.5 }) {
  if (!prices || prices.length < params.lookback + 1) return 0;
  const slice = prices.slice(-params.lookback);
  const mean = slice.reduce((s, v) => s + v, 0) / slice.length;
  const std = Math.sqrt(slice.reduce((s, v) => s + (v - mean) ** 2, 0) / slice.length);
  const last = prices[prices.length - 1];
  const z = std === 0 ? 0 : (last - mean) / std;
  if (z > params.z) return -1; // sell (price high)
  if (z < -params.z) return 1; // buy (price low)
  return 0;
}

export function gridSignal(prices, params = { gridSize: 5, stepPct: 0.01 }) {
  // grid uses discrete levels; simple heuristic: if price moved > stepPct since last trade, flip signal
  // This function is a placeholder � implement based on stored grid state per bot
  return 0;
}

export function runStrategy(bot, prices) {
  switch (bot.type) {
    case "momentum":
      return emaCrossoverSignal(prices, { fast: bot.params?.fast || 9, slow: bot.params?.slow || 20, threshold: bot.params?.threshold || 0.002 });
    case "mean_reversion":
      return zscoreMeanReversionSignal(prices, { lookback: bot.params?.lookback || 50, z: bot.params?.zscore || 1.5 });
    case "grid":
      return gridSignal(prices, bot.params || {});
    default:
      return 0;
  }
}