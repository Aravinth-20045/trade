// src/services/web3.js
// -------------------------------------------
// Centralized Web3 service for MetaMask + SelinaToken interaction
// Uses ethers.js v6 for modern API
// -------------------------------------------

import { ethers } from "ethers";

// ---------- CONFIG: UPDATE TO YOUR DEPLOYED TOKEN DETAILS ----------
const TOKEN_ADDRESS = "0xab69946664AAF7D1164FA2fcf4a2429e062f2178"; // SelinaToken (Sepolia)
const TOKEN_ABI = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function totalSupply() view returns (uint256)",
  "function balanceOf(address) view returns (uint256)",
  "function transfer(address,uint256) returns (bool)"
];
// -------------------------------------------------------------------

let provider;
let signer;
let tokenContract;

/**
 * Initialize provider if MetaMask is available.
 * Will throw if no injected provider is found.
 */
export async function initProvider() {
  if (typeof window.ethereum === "undefined") {
    throw new Error("MetaMask not detected. Install MetaMask extension.");
  }
  provider = new ethers.BrowserProvider(window.ethereum);
  return provider;
}

/**
 * Request wallet connection and return the connected account.
 * Also sets up signer & token contract instance.
 */
export async function connectWallet() {
  if (!provider) await initProvider();
  const accounts = await provider.send("eth_requestAccounts", []);
  if (!accounts || accounts.length === 0) throw new Error("No account found.");
  signer = await provider.getSigner();
  tokenContract = new ethers.Contract(TOKEN_ADDRESS, TOKEN_ABI, signer);
  subscribeToEvents();
  return accounts[0];
}

/**
 * Get currently connected account without prompting.
 */
export async function getCurrentAccount() {
  if (!provider) await initProvider();
  const accounts = await provider.send("eth_accounts", []);
  return accounts[0] || null;
}

/**
 * Get ETH balance (in ETH) of the given address (or current signer if omitted).
 */
export async function getEthBalance(address) {
  if (!provider) await initProvider();
  const target = address || (signer ? await signer.getAddress() : null);
  if (!target) throw new Error("No account to fetch balance for.");
  const balanceWei = await provider.getBalance(target);
  return ethers.formatEther(balanceWei);
}

/**
 * Get network details: chainId and name
 */
export async function getNetwork() {
  if (!provider) await initProvider();
  const network = await provider.getNetwork();
  return {
    chainId: network.chainId.toString(),
    name: network.name
  };
}

// ---------- SelinaToken specific helpers ----------

export async function getTokenName() {
  if (!tokenContract) throw new Error("Wallet not connected.");
  return tokenContract.name();
}

export async function getTokenSymbol() {
  if (!tokenContract) throw new Error("Wallet not connected.");
  return tokenContract.symbol();
}

export async function getTokenDecimals() {
  if (!tokenContract) throw new Error("Wallet not connected.");
  return tokenContract.decimals();
}

export async function getTokenBalance(address) {
  if (!tokenContract) throw new Error("Wallet not connected.");
  const decimals = await getTokenDecimals();
  const bal = await tokenContract.balanceOf(address);
  return ethers.formatUnits(bal, decimals);
}

/**
 * Transfer token to another address
 * @param {string} to - recipient address
 * @param {string|number} amount - amount in human-readable units (not wei)
 */
export async function transferToken(to, amount) {
  if (!tokenContract) throw new Error("Wallet not connected.");
  const decimals = await getTokenDecimals();
  const amountWei = ethers.parseUnits(amount.toString(), decimals);
  const tx = await tokenContract.transfer(to, amountWei);
  await tx.wait();
  return tx.hash;
}

// ---------- Event subscriptions for UI reactivity ----------

function subscribeToEvents() {
  if (!window.ethereum) return;
  window.ethereum.on("accountsChanged", (accounts) => {
    console.log("Accounts changed:", accounts);
    // Optionally trigger a page reload or callback
  });
  window.ethereum.on("chainChanged", (chainId) => {
    console.log("Chain changed:", chainId);
    // EIP-1193 recommends reloading the page
    window.location.reload();
  });
}

// ---------- Convenience: auto-init provider on module import ----------
(async () => {
  try {
    await initProvider();
    console.log("Web3 provider initialized");
  } catch (err) {
    console.warn("Provider not initialized:", err.message);
  }
})();

export default {
  initProvider,
  connectWallet,
  getCurrentAccount,
  getEthBalance,
  getNetwork,
  getTokenName,
  getTokenSymbol,
  getTokenDecimals,
  getTokenBalance,
  transferToken
};
