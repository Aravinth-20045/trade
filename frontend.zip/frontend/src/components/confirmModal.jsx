﻿import React from "react";

/**
 * ConfirmModal – small reusable confirmation dialog
 *
 * Props:
 * - open: boolean
 * - title: string
 * - children: node (details)
 * - confirmLabel: string
 * - onConfirm(): void
 * - onCancel(): void
 *
 * Renders simple centered modal with backdrop. Keeps styling minimal and consistent with app theme.
 */
export default function ConfirmModal({ open, title, children, confirmLabel = "Confirm", onConfirm, onCancel }) {
  if (!open) return null;

  return (
    <div style={backdropStyle}>
      <div style={modalStyle}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ fontSize: 16, fontWeight: 800 }}>{title}</div>
          <button onClick={onCancel} style={closeBtnStyle} aria-label="Close">✕</button>
        </div>

        <div style={{ marginBottom: 18, color: "#dbeefe" }}>{children}</div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
          <button className="btn small ghost" onClick={onCancel}>Cancel</button>
          <button className="btn small" onClick={onConfirm}>{confirmLabel}</button>
        </div>
      </div>
    </div>
  );
}

/* Inline styles keep it self-contained and matching dark UI */
const backdropStyle = {
  position: "fixed",
  inset: 0,
  background: "rgba(2,6,23,0.6)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 9999,
  padding: 20,
};

const modalStyle = {
  width: "100%",
  maxWidth: 520,
  background: "linear-gradient(180deg,#071018,#0b1116)",
  borderRadius: 12,
  padding: 18,
  border: "1px solid rgba(255,255,255,0.04)",
  boxShadow: "0 20px 60px rgba(0,0,0,0.7)",
  color: "#e6edf3",
};

const closeBtnStyle = {
  background: "transparent",
  border: "none",
  color: "#9aa4ad",
  fontSize: 16,
  cursor: "pointer",
};