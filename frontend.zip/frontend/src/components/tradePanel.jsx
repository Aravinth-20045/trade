import React, { useState } from "react";
import ConfirmModal from "./confirmModal.jsx";

/**
 * TradePanel (enhanced)
 *
 * Props:
 * - asset: string
 * - balanceCash: number
 * - equity: number
 * - onTrade(type, amount, price, extra)
 *
 * Features:
 * - Market / Limit modes (simulated)
 * - Percent size presets (approximation when price unknown)
 * - Confirmation modal showing order summary (prevents accidental 100x trades)
 * - Clear input validation and small UX polish
 */

export default function TradePanel({ asset, balanceCash = 0, equity = null, onTrade }) {
  const [amount, setAmount] = useState("0.001");
  const [orderType, setOrderType] = useState("MARKET"); // MARKET | LIMIT
  const [limitPrice, setLimitPrice] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pending, setPending] = useState(null); // { type, amount, price }

  const leverage = 100;

  const priceMap = { sBTC: 20000, sETH: 1500, SEL: 0.02 };
  const approxPrice = priceMap[asset] || 1;

  const parseAmount = (v) => {
    const n = typeof v === "string" ? parseFloat(v) : Number(v);
    return Number.isFinite(n) ? n : 0;
  };

  const setPercent = (pct) => {
    const cash = typeof balanceCash === "number" ? balanceCash : 0;
    if (cash <= 0) {
      alert("No demo cash available");
      return;
    }
    const notional = (pct / 100) * cash;
    const approxAmt = Number((notional / approxPrice).toFixed(8));
    setAmount(String(approxAmt));
  };

  const openConfirm = (side) => {
    const amt = parseAmount(amount);
    if (!amt || amt <= 0) {
      alert("Enter valid amount");
      return;
    }
    const price = orderType === "LIMIT" ? parseFloat(limitPrice) : null;
    // sanity: if limit selected but no price input, warn
    if (orderType === "LIMIT" && (!price || price <= 0)) {
      alert("Enter a valid limit price");
      return;
    }
    setPending({ type: side, amount: amt, price: price || null });
    setConfirmOpen(true);
  };

  const confirmTrade = () => {
    if (!pending) return;
    const { type, amount: amt, price } = pending;
    onTrade(type, amt, price, { source: "QuickTrade", leverage, orderType });
    setConfirmOpen(false);
    setPending(null);
  };

  return (
    <div className="quick-trade" style={{ width: "100%" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <div style={{ fontWeight: 800, fontSize: 15 }}>Quick Trade</div>
        <div style={{ color: "var(--muted)", fontSize: 12 }}>Leverage: <strong>{leverage}x</strong></div>
      </div>

      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
        <input
          className="input"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="Amount"
          style={{ flex: 1 }}
        />
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <button className="btn small" onClick={() => openConfirm("BUY")} style={{ background: "var(--positive)", color: "#071014" }}>
            Buy
          </button>
          <button className="btn small" onClick={() => openConfirm("SELL")} style={{ background: "var(--negative)", color: "#071014" }}>
            Sell
          </button>
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
        <div className="percent-buttons" style={{ display: "flex", gap: 8 }}>
          <button className="btn small ghost" onClick={() => setPercent(5)}>5%</button>
          <button className="btn small ghost" onClick={() => setPercent(25)}>25%</button>
          <button className="btn small ghost" onClick={() => setPercent(50)}>50%</button>
          <button className="btn small ghost" onClick={() => setPercent(100)}>100%</button>
        </div>

        <div style={{ marginLeft: "auto", textAlign: "right", color: "var(--muted)", fontSize: 13 }}>
          Cash: <span className="mono">{balanceCash ?? "—"}</span>
          {equity != null && <> · Equity: <span className="mono">{equity}</span></>}
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "center" }}>
        <label style={{ color: "var(--muted)", fontSize: 13 }}>
          <input type="radio" name="type" value="MARKET" checked={orderType === "MARKET"} onChange={() => setOrderType("MARKET")} style={{ marginRight: 8 }} />
          Market
        </label>
        <label style={{ color: "var(--muted)", fontSize: 13 }}>
          <input type="radio" name="type" value="LIMIT" checked={orderType === "LIMIT"} onChange={() => setOrderType("LIMIT")} style={{ marginRight: 8 }} />
          Limit
        </label>

        {orderType === "LIMIT" && (
          <input
            className="input"
            placeholder={`Limit price (e.g. ${approxPrice})`}
            value={limitPrice}
            onChange={(e) => setLimitPrice(e.target.value)}
            style={{ marginLeft: 8, width: 140 }}
          />
        )}
      </div>

      <div style={{ marginTop: 10, color: "var(--muted)", fontSize: 12 }}>
        Orders are simulated. Opening a position locks margin = (notional / {leverage}).
      </div>

      <ConfirmModal
        open={confirmOpen}
        title={pending ? `${pending.type} ${asset}` : "Confirm Order"}
        confirmLabel="Execute"
        onConfirm={confirmTrade}
        onCancel={() => { setConfirmOpen(false); setPending(null); }}
      >
        {pending ? (
          <>
            <div style={{ marginBottom: 8 }}>
              <strong>Side:</strong> {pending.type}
            </div>
            <div style={{ marginBottom: 8 }}>
              <strong>Amount:</strong> <span className="mono">{pending.amount}</span> {asset}
            </div>
            <div style={{ marginBottom: 8 }}>
              <strong>Price:</strong> {pending.price ? `$${pending.price}` : "Market"}
            </div>
            <div style={{ marginBottom: 8 }}>
              <strong>Leverage:</strong> {leverage}x
            </div>
            <div style={{ marginTop: 8, color: "var(--muted)" }}>
              Estimated margin: <strong>{Number(((pending.amount * (pending.price || approxPrice)) / leverage).toFixed(8))}</strong>
            </div>
          </>
        ) : null}
      </ConfirmModal>
    </div>
  );
}
