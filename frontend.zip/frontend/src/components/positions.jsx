import React, { useState } from "react";
import ConfirmModal from "./confirmModal.jsx";

/**
 * PositionsPanel (updated)
 *
 * Props:
 * - positions: { [asset]: Array<position> }
 * - currentPrices: { [asset]: price }
 * - onClosePosition(asset, positionId)
 *
 * Adds confirmation modal and small UI polish.
 */

function PositionsPanelInner({ positions = {}, currentPrices = {}, onClosePosition }) {
  const [confirm, setConfirm] = useState({ open: false, asset: null, posId: null });

  const assets = Object.keys(positions);

  const openCloseConfirm = (asset, pos) => {
    setConfirm({ open: true, asset, posId: pos.id, pos });
  };

  const doClose = () => {
    if (!confirm.open) return;
    onClosePosition(confirm.asset, confirm.posId);
    setConfirm({ open: false, asset: null, posId: null });
  };

  const renderPosition = (pos, asset) => {
    const price = currentPrices[asset] ?? pos.entryPrice;
    const notional = pos.amount * pos.entryPrice;
    const margin = notional / pos.leverage;
    const unrealized = pos.side === "LONG" ? (price - pos.entryPrice) * pos.amount : (pos.entryPrice - price) * pos.amount;
    const pnl = Number(unrealized.toFixed(8));
    return (
      <div key={pos.id} className="position-row" style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <div style={{ fontWeight: 800 }}>{asset}</div>
            <div style={{ fontSize: 12, color: "var(--muted)" }}>{pos.side}</div>
          </div>
          <div style={{ fontSize: 13, color: "var(--muted)", marginTop: 6 }}>
            Amount: <span className="mono">{pos.amount}</span> � Entry: <span className="mono">{pos.entryPrice}</span>
          </div>
          <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 6 }}>Opened: <span className="mono">{pos.openedAt}</span></div>
        </div>

        <div style={{ textAlign: "right", minWidth: 140 }}>
          <div style={{ fontWeight: 800 }}>
            {pnl >= 0 ? <span style={{ color: "var(--positive)" }}>+{pnl}</span> : <span style={{ color: "var(--negative)" }}>{pnl}</span>}
          </div>
          <div style={{ fontSize: 13, color: "var(--muted)", marginTop: 6 }}>Margin: <span className="mono">{Number(margin.toFixed(8))}</span></div>
          <div style={{ marginTop: 8, display: "flex", justifyContent: "flex-end", gap: 8 }}>
            <button className="btn small ghost" onClick={() => openCloseConfirm(asset, pos)}>Close</button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <div style={{ fontWeight: 800 }}>Open Positions</div>
        <div style={{ fontSize: 13, color: "var(--muted)" }}>{assets.length === 0 ? "No positions" : assets.reduce((s, a) => s + (positions[a] || []).length, 0) + " total"}</div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {assets.length === 0 ? (
          <div style={{ color: "var(--muted)" }}>You have no open positions.</div>
        ) : (
          assets.map((asset) => (
            <div key={asset} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {(positions[asset] || []).map((p) => renderPosition(p, asset))}
            </div>
          ))
        )}
      </div>

      <ConfirmModal
        open={confirm.open}
        title="Close Position?"
        confirmLabel="Close Position"
        onConfirm={doClose}
        onCancel={() => setConfirm({ open: false, asset: null, posId: null })}
      >
        {confirm.open && (
          <div>
            <div style={{ marginBottom: 8 }}>Close position on <strong>{confirm.asset}</strong></div>
            <div style={{ color: "var(--muted)" }}>This will realize PnL and return margin + PnL to your cash balance.</div>
          </div>
        )}
      </ConfirmModal>
    </div>
  );
}

export default React.memo(PositionsPanelInner);