import React, { useState, useEffect } from "react";
import { ethers } from "ethers";

/**
 * WalletConnect – MetaMask connector + persistent Demo account toggle
 *
 * Changes:
 * - Persist demo selection and demo cash to localStorage (keys: selina_demo, selina_demo_cash)
 * - On mount, auto-select demo account if persisted
 * - Expose a clear "Use Demo Account" toggle and keep MetaMask connect button
 * - When demo selected, setAccount('demo') and setBalance(demoCash)
 */

const DEMO_KEY = "selina_demo";
const DEMO_CASH_KEY = "selina_demo_cash";

export default function WalletConnect({ account, setAccount, setBalance }) {
  const [provider, setProvider] = useState(null);
  const [chainName, setChainName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const [demoCash, setDemoCash] = useState(() => {
    try {
      const v = localStorage.getItem(DEMO_CASH_KEY);
      return v ? Number(v) : 1000;
    } catch {
      return 1000;
    }
  });
  const [useDemo, setUseDemo] = useState(() => {
    try {
      return localStorage.getItem(DEMO_KEY) === "1";
    } catch {
      return false;
    }
  });

  // Initialize provider & auto-reconnect; also handle persisted demo account on mount
  useEffect(() => {
    if (useDemo) {
      // restore demo account
      setAccount("demo");
      if (setBalance) setBalance(Number(demoCash));
      return; // still initialize provider for when user wants to switch to MetaMask
    }

    if (!window.ethereum) {
      // no provider found — user can still use demo
      return;
    }

    const _provider = new ethers.BrowserProvider(window.ethereum);
    setProvider(_provider);

    (async () => {
      try {
        const accounts = await window.ethereum.request({ method: "eth_accounts" });
        if (accounts.length > 0) {
          setAccount(accounts[0]);
          await fetchChainName(_provider);
          if (setBalance) {
            const bal = await _provider.getBalance(accounts[0]);
            setBalance(ethers.formatEther(bal));
          }
        }
      } catch (err) {
        console.error(err);
      }
    })();

    const handleAccounts = async (accounts) => {
      if (accounts.length === 0) {
        setAccount(null);
        if (setBalance) setBalance(null);
      } else {
        setAccount(accounts[0]);
        if (setBalance) {
          try {
            const balance = await _provider.getBalance(accounts[0]);
            setBalance(ethers.formatEther(balance));
          } catch (err) {
            console.error("Failed to fetch balance:", err);
          }
        }
      }
    };

    const handleChainChanged = async () => {
      await fetchChainName(_provider);
    };

    window.ethereum.on("accountsChanged", handleAccounts);
    window.ethereum.on("chainChanged", handleChainChanged);

    return () => {
      try {
        window.ethereum.removeEventListener && window.ethereum.removeEventListener("accountsChanged", handleAccounts);
        window.ethereum.removeEventListener && window.ethereum.removeEventListener("chainChanged", handleChainChanged);
      } catch (e) {}
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // persist useDemo/demoCash when changed
  useEffect(() => {
    try {
      localStorage.setItem(DEMO_KEY, useDemo ? "1" : "0");
      localStorage.setItem(DEMO_CASH_KEY, String(demoCash));
    } catch (e) {}
  }, [useDemo, demoCash]);

  const fetchChainName = async (_provider) => {
    try {
      const network = await _provider.getNetwork();
      const displayName = network.name && network.name !== "unknown" ? network.name : `Chain ${network.chainId}`;
      setChainName(displayName);
    } catch (err) {
      setError(`Network error: ${err.message}`);
    }
  };

  const connectWallet = async () => {
    setError("");
    setLoading(true);
    try {
      if (!provider) throw new Error("No Ethereum provider found");
      const accounts = await provider.send("eth_requestAccounts", []);
      setAccount(accounts[0]);
      await fetchChainName(provider);
      if (setBalance) {
        const balance = await provider.getBalance(accounts[0]);
        setBalance(ethers.formatEther(balance));
      }
      // if user connects real wallet, disable demo mode
      if (useDemo) setUseDemo(false);
    } catch (err) {
      setError(err?.message || String(err));
    } finally {
      setLoading(false);
    }
  };

  const toggleDemo = (enabled) => {
    setUseDemo(enabled);
    try {
      if (enabled) {
        setAccount("demo");
        if (setBalance) setBalance(Number(demoCash));
      } else {
        // disable demo: clear demo account but do not auto-connect wallet
        setAccount(null);
        if (setBalance) setBalance(null);
      }
    } catch (e) {}
  };

  const disconnectWallet = () => {
    setAccount(null);
    if (setBalance) setBalance(null);
    // keep demo choice intact
  };

  const shortenAddress = (addr) => (addr ? `${addr.slice(0, 6)}…${addr.slice(-4)}` : "");

  return (
    <div style={styles.container}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2 style={styles.heading}>Connection</h2>
        <div style={{ fontSize: 12, color: "#9aa4ad" }}>Demo toggle</div>
      </div>

      {error && <p style={styles.error}>{error}</p>}

      {!account ? (
        <>
          <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
            <button style={{ ...styles.button, opacity: loading ? 0.7 : 1 }} onClick={connectWallet} disabled={loading}>
              {loading ? "Connecting…" : "Connect MetaMask"}
            </button>

            <button
              style={{ ...styles.button, background: useDemo ? "#0ea5a4" : "#17a2b8", width: 140 }}
              onClick={() => toggleDemo(true)}
            >
              Use Demo
            </button>
          </div>

          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <input
              value={demoCash}
              onChange={(e) => setDemoCash(Number(e.target.value || 0))}
              className="input"
              style={{ width: 120 }}
              type="number"
              placeholder="Demo cash"
            />
            <label style={{ color: "#cfeffc", fontSize: 13 }}>
              <input
                type="checkbox"
                checked={useDemo}
                onChange={(e) => toggleDemo(e.target.checked)}
                style={{ marginRight: 8 }}
              />
              Enable demo
            </label>
          </div>
        </>
      ) : (
        <div style={styles.infoBox}>
          <p>
            <strong>Network:</strong> {chainName || "Demo / Detecting…"}
          </p>
          <p>
            <strong>Address:</strong> {account === "demo" ? "Demo Account" : shortenAddress(account)}
          </p>
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button style={{ ...styles.button, background: "#dc3545" }} onClick={disconnectWallet}>
              Disconnect
            </button>
            {account === "demo" ? (
              <button
                style={{ ...styles.button, background: "#f59e0b" }}
                onClick={() => {
                  // open demo cash edit quickly
                  const v = prompt("Set demo cash amount", String(demoCash));
                  if (v != null) {
                    const n = Number(v || 0);
                    setDemoCash(n);
                    if (setBalance) setBalance(n);
                  }
                }}
              >
                Edit Demo Cash
              </button>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------- Inline Styles ------------------- */
const styles = {
  container: {
    border: "1px solid rgba(255,255,255,0.06)",
    borderRadius: "10px",
    padding: "1rem",
    maxWidth: "360px",
    margin: "0.5rem auto",
    background: "rgba(18,20,26,0.7)",
    color: "#e6edf3",
    fontFamily: "Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial",
  },
  heading: {
    marginTop: 0,
    textAlign: "left",
    color: "#9feaf5",
    fontSize: "0.95rem",
  },
  button: {
    padding: "0.5rem 0.9rem",
    background: "#007bff",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "0.95rem",
    transition: "background 0.15s ease",
  },
  infoBox: {
    textAlign: "left",
    fontSize: "0.95rem",
    wordBreak: "break-word",
    lineHeight: "1.4",
  },
  error: {
    color: "#ff6b6b",
    fontWeight: "700",
    textAlign: "center",
    marginBottom: "0.6rem",
  },
};
