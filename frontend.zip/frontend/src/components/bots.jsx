import React, { useState } from "react";

/**
 * BotsPanel - simple, professional-looking UI for managing bots
 *
 * Props:
 * - bots: array of bot objects {id, name, type, params, enabled}
 * - onAddBot(bot)
 * - onUpdateBot(id, patch)
 * - onRemoveBot(id)
 *
 * Notes:
 * - This component is intentionally lightweight and purely UI + local settings.
 * - Algorithms are represented by type + params. For safety demos we do not execute arbitrary code here.
 */

export default function BotsPanel({ bots = [], onAddBot, onUpdateBot, onRemoveBot }) {
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    name: "",
    type: "momentum",
    params: { lookback: 20, threshold: 0.002, amount: 0.01 },
  });

  const presets = [
    {
      key: "momentum",
      label: "Momentum (EMA crossover)",
      params: { lookback: 20, threshold: 0.002, amount: 0.01 },
    },
    {
      key: "mean_reversion",
      label: "Mean Reversion (z-score)",
      params: { lookback: 50, zscore: 1.5, amount: 0.01 },
    },
    {
      key: "grid",
      label: "Grid (buy/sell grid)",
      params: { gridSize: 5, stepPct: 0.01, amount: 0.01 },
    },
  ];

  const startCreating = (presetKey) => {
    const preset = presets.find((p) => p.key === presetKey) || presets[0];
    setForm({
      name: `${preset.label}`,
      type: preset.key,
      params: { ...preset.params },
    });
    setCreating(true);
  };

  const createBot = () => {
    if (!form.name) return alert("Please give the bot a name");
    onAddBot({
      name: form.name,
      type: form.type,
      params: form.params,
      enabled: true,
    });
    setCreating(false);
    setForm({
      name: "",
      type: "momentum",
      params: { lookback: 20, threshold: 0.002, amount: 0.01 },
    });
  };

  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <div>
          <div style={{ fontWeight: 700 }}>Bots</div>
          <div style={{ fontSize: 12, color: "var(--muted)" }}>Presets + custom bots � simulated demo</div>
        </div>

        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn small ghost" onClick={() => startCreating("momentum")}>New Momentum</button>
          <button className="btn small ghost" onClick={() => startCreating("mean_reversion")}>New MeanReversion</button>
          <button className="btn small ghost" onClick={() => startCreating("grid")}>New Grid</button>
        </div>
      </div>

      <div style={{ marginTop: 10 }}>
        {bots.length === 0 ? (
          <div style={{ color: "var(--muted)", fontSize: 13 }}>No bots yet � create one from presets.</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {bots.map((b) => (
              <div key={b.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "var(--panel)", padding: 8, borderRadius: 8 }}>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <div style={{ width: 10, height: 10, borderRadius: 3, background: b.enabled ? "var(--accent)" : "#555" }} />
                  <div>
                    <div style={{ fontWeight: 700 }}>{b.name}</div>
                    <div style={{ fontSize: 12, color: "var(--muted)" }}>{b.type} � amount: {b.params?.amount ?? "�"}</div>
                  </div>
                </div>

                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <label style={{ fontSize: 12, color: "var(--muted)" }}>
                    <input
                      type="checkbox"
                      checked={b.enabled}
                      onChange={(e) => onUpdateBot(b.id, { enabled: e.target.checked })}
                      style={{ marginRight: 6 }}
                    />
                    Enabled
                  </label>
                  <button className="btn small ghost" onClick={() => {
                    const newName = prompt("Rename bot", b.name);
                    if (newName) onUpdateBot(b.id, { name: newName });
                  }}>Edit</button>
                  <button className="btn small danger" onClick={() => {
                    if (confirm(`Remove bot "${b.name}"?`)) onRemoveBot(b.id);
                  }}>Remove</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {creating && (
        <div style={{ marginTop: 12, background: "var(--panel)", padding: 12, borderRadius: 8 }}>
          <div style={{ marginBottom: 8, fontWeight: 700 }}>Create Custom Bot</div>

          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <input
              placeholder="Bot name"
              value={form.name}
              onChange={(e) => setForm((s) => ({ ...s, name: e.target.value }))}
              className="input"
            />

            <select
              value={form.type}
              onChange={(e) => {
                const preset = presets.find((p) => p.key === e.target.value);
                setForm((s) => ({ ...s, type: e.target.value, params: preset ? { ...preset.params } : s.params }));
              }}
              className="input"
            >
              {presets.map((p) => (
                <option key={p.key} value={p.key}>{p.label}</option>
              ))}
              <option value="custom">Custom</option>
            </select>

            {/* simple params editor */}
            <div style={{ display: "flex", gap: 8 }}>
              <input
                className="input"
                style={{ flex: 1 }}
                type="number"
                step="0.0001"
                value={form.params.amount}
                onChange={(e) => setForm((s) => ({ ...s, params: { ...s.params, amount: parseFloat(e.target.value) || 0 } }))}
                placeholder="Amount"
              />
              <input
                className="input"
                style={{ width: 120 }}
                type="number"
                value={form.params.lookback ?? form.params.gridSize ?? form.params.zscore ?? ""}
                onChange={(e) => {
                  const v = parseFloat(e.target.value) || 0;
                  setForm((s) => ({ ...s, params: { ...s.params, lookback: v } }));
                }}
                placeholder="Lookback"
              />
            </div>

            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button className="btn small ghost" onClick={() => setCreating(false)}>Cancel</button>
              <button className="btn small" onClick={createBot}>Create & Enable</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}