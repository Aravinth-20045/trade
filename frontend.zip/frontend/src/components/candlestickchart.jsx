import React, { useEffect, useState, useCallback, useRef, useMemo } from "react";
import Chart from "react-apexcharts";

/*
  Improvements:
  - ResizeObserver on container to trigger chart.resize() after left-panel animation.
  - Disable animations while resizing to reduce jank.
  - Throttle WS updates to target ~25 FPS (safe for low-end devices).
  - Offload EMA/series state application to setTimeout to avoid main-thread blocking.
*/

function mapAssetToSymbol(asset) {
  if (asset === "sBTC") return "BTCUSDT";
  if (asset === "sETH") return "ETHUSDT";
  return null;
}

function parseKlinesToSeries(klines) {
  return klines.map((k) => {
    const ts = new Date(k[0]);
    return {
      x: ts,
      y: [Number(k[1]), Number(k[2]), Number(k[3]), Number(k[4])],
    };
  });
}

export default function CandlestickChart({ asset = "sBTC", trades = [] }) {
  const [dataLoaded, setDataLoaded] = useState(false);
  const [theme, setTheme] = useState("dark");
  const [showEMA, setShowEMA] = useState(true);
  const [interval, setIntervalState] = useState(1); // minutes per candle
  const [isResizing, setIsResizing] = useState(false);

  const chartRef = useRef(null);
  const containerRef = useRef(null);
  const latestDataRef = useRef([]); // mutable copy of candles
  const wsRef = useRef(null);
  const lastUpdateRef = useRef(0); // throttling timestamp

  const symbol = mapAssetToSymbol(asset);

  // Series stored as state (Chart reads it)
  const [seriesState, setSeriesState] = useState([
    { name: "Candles", type: "candlestick", data: [] },
    ...(showEMA ? [{ name: "EMA (10)", type: "line", data: [] }] : []),
  ]);

  const buildBaseOptions = useCallback(
    (resizingFlag = false) => ({
      chart: {
        type: "candlestick",
        height: 420,
        background: theme === "dark" ? "#0b0c10" : "#ffffff",
        foreColor: theme === "dark" ? "#e6edf3" : "#333333",
        zoom: { enabled: true, type: "x", autoScaleYaxis: true },
        toolbar: {
          show: true,
          tools: {
            download: true,
            selection: true,
            zoom: true,
            zoomin: true,
            zoomout: true,
            pan: true,
            reset: true,
          },
        },
        // disable heavy animations during resize to avoid jank
        animations: {
          enabled: !resizingFlag,
          easing: "linear",
          dynamicAnimation: { enabled: !resizingFlag, speed: 300 },
        },
        events: {},
      },
      title: {
        text: `${asset} – ${interval}m`,
        align: "left",
        style: { color: theme === "dark" ? "#fff" : "#000" },
      },
      xaxis: { type: "datetime", labels: { datetimeUTC: false } },
      yaxis: { tooltip: { enabled: true }, opposite: true, tickAmount: 6, forceNiceScale: true },
      grid: { borderColor: theme === "dark" ? "#222" : "#e6e6e6" },
      tooltip: { theme: theme },
      annotations: { points: [] },
      stroke: { width: [1, 2], curve: "smooth" },
      colors: ["#00b894"],
    }),
    [asset, interval, theme]
  );

  const [optionsState, setOptionsState] = useState(buildBaseOptions(false));

  const fetchKlines = useCallback(async (sym, intervalStr, limit = 200) => {
    if (!sym) return null;
    try {
      const res = await fetch(
        `https://api.binance.com/api/v3/klines?symbol=${sym}&interval=${intervalStr}&limit=${limit}`
      );
      if (!res.ok) throw new Error("Klines fetch failed");
      const json = await res.json();
      return parseKlinesToSeries(json);
    } catch (e) {
      console.warn("Failed to fetch klines:", e);
      return null;
    }
  }, []);

  const calculateEMA = useCallback((source, period = 10) => {
    if (!source || source.length === 0) return [];
    const k = 2 / (period + 1);
    const out = [];
    let ema = source[0].y[3];
    out.push({ x: source[0].x, y: ema });
    for (let i = 1; i < source.length; i++) {
      ema = source[i].y[3] * k + ema * (1 - k);
      out.push({ x: source[i].x, y: ema });
    }
    return out;
  }, []);

  // Update series with EMA computation off the critical path (async step)
  const updateChartSeries = useCallback(
    (seriesData) => {
      try {
        latestDataRef.current = seriesData;

        // compute EMA (if needed) asynchronously to avoid blocking UI
        if (showEMA) {
          setTimeout(() => {
            const emaSeries = calculateEMA(seriesData);
            const payload = [
              { name: "Candles", type: "candlestick", data: seriesData },
              {
                name: "EMA (10)",
                type: "line",
                data: emaSeries.map((p) => ({ x: p.x, y: p.y })),
              },
            ];
            // update chart in-place if possible
            if (chartRef.current && chartRef.current.chart) {
              try {
                chartRef.current.chart.updateSeries(payload, true);
                chartRef.current.chart.updateOptions({ title: { text: `${asset} – ${interval}m` } }, false, false);
              } catch (e) {
                setSeriesState(payload);
              }
            } else {
              setSeriesState(payload);
            }
          }, 0);
        } else {
          const payload = [{ name: "Candles", type: "candlestick", data: seriesData }];
          if (chartRef.current && chartRef.current.chart) {
            try {
              chartRef.current.chart.updateSeries(payload, true);
              chartRef.current.chart.updateOptions({ title: { text: `${asset} – ${interval}m` } }, false, false);
            } catch (e) {
              setSeriesState(payload);
            }
          } else {
            setSeriesState(payload);
          }
        }
      } catch (e) {
        console.warn("updateChartSeries error", e);
      }
    },
    [calculateEMA, showEMA, asset, interval]
  );

  // initial load + periodic full refresh (throttled)
  useEffect(() => {
    let mounted = true;
    const loadData = async () => {
      if (!symbol) return;
      const intMap = interval === 60 ? "1h" : `${interval}m`;
      const series = await fetchKlines(symbol, intMap, 200);
      if (mounted && series && series.length) {
        updateChartSeries(series);
        setDataLoaded(true);
      }
    };

    loadData().catch(() => {});
    const ms = Math.max(30000, interval * 60 * 1000);
    const id = setInterval(() => loadData().catch(() => {}), ms);
    return () => {
      mounted = false;
      clearInterval(id);
    };
  }, [symbol, interval, fetchKlines, updateChartSeries]);

  // WebSocket / per-tick updates for 1m interval with FPS throttle (~25 FPS)
  useEffect(() => {
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch (e) {}
      wsRef.current = null;
    }

    if (!symbol || interval !== 1) {
      return;
    }

    const streamName = `${symbol.toLowerCase()}@trade`;
    const url = `wss://stream.binance.com:9443/ws/${streamName}`;
    const ws = new WebSocket(url);
    wsRef.current = ws;

    let rafId = null;

    ws.onmessage = (evt) => {
      try {
        const msg = JSON.parse(evt.data);
        const price = Number(parseFloat(msg.p || msg.price).toFixed(6));
        const ts = msg.T || msg.tradeTime || Date.now();

        const prev = latestDataRef.current;
        if (!prev || prev.length === 0) return;

        const copy = prev.slice();
        const last = copy[copy.length - 1];
        const lastTs = last.x instanceof Date ? last.x.getTime() : new Date(last.x).getTime();
        const minuteStart = Math.floor(ts / 60000) * 60000;

        if (lastTs < minuteStart) {
          // new minute: skip per-tick update (periodic loader will pick it up)
          return;
        }

        const open = last.y[0];
        const prevHigh = last.y[1];
        const prevLow = last.y[2];
        const high = Math.max(prevHigh, price);
        const low = Math.min(prevLow, price);
        const close = price;
        const newCandle = { x: new Date(ts), y: [open, high, low, close] };
        copy[copy.length - 1] = newCandle;
        latestDataRef.current = copy;

        // batch updates via requestAnimationFrame + throttle to target ~25 FPS
        if (rafId) cancelAnimationFrame(rafId);
        rafId = requestAnimationFrame(() => {
          const now = performance.now();
          const MIN_FRAME_MS = 40; // ~25 FPS (40ms)
          if (now - lastUpdateRef.current < MIN_FRAME_MS) {
            // skip this frame to keep CPU low on slow devices
            return;
          }
          lastUpdateRef.current = now;

          if (chartRef.current && chartRef.current.chart) {
            try {
              chartRef.current.chart.updateSeries([{ name: "Candles", data: copy }], true);
            } catch (e) {
              setSeriesState((s) => {
                const next = s.slice();
                next[0] = { ...next[0], data: copy };
                return next;
              });
            }
          } else {
            setSeriesState((s) => {
              const next = s.slice();
              next[0] = { ...next[0], data: copy };
              return next;
            });
          }
        });
      } catch (e) {
        // ignore malformed messages
      }
    };

    ws.onopen = () => {};
    ws.onerror = () => {};
    ws.onclose = () => {};

    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      try {
        ws.close();
      } catch (e) {}
      wsRef.current = null;
    };
  }, [symbol, interval]);

  // Fallback simulated series for SEL or unsupported symbols
  useEffect(() => {
    if (!symbol) {
      // choose reasonable start price per synthetic asset
      const startPrices = {
        SEL: 0.02,
        sBTC: 26000,
        sETH: 1500,
        sGOLD: 1960,   // USD/oz start
        sEURUSD: 1.10, // forex
        sNIFTY: 19500, // index level
      };
      const startPrice = startPrices[asset] ?? 1000;
      const fallback = generateFallbackSeries(200, startPrice);
      latestDataRef.current = fallback;
      updateChartSeries(fallback);
      setDataLoaded(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [symbol, asset]);

  // Build trade annotations and update optionsState so Chart rerenders annotations
  const tradeAnnotations = useMemo(() => {
    if (!trades || trades.length === 0) return [];
    return trades
      .filter((t) => t.asset === asset)
      .map((t) => {
        const x = t.ts ? new Date(t.ts) : new Date(t.time);
        const y = t.price;
        const isBuy = (t.type || "").toUpperCase() === "BUY";
        return {
          x,
          y,
          marker: {
            size: 8,
            fillColor: isBuy ? "#10b981" : "#ef4444",
            strokeColor: "#fff",
            strokeWidth: 2,
            cssClass: isBuy ? "trade-marker-buy" : "trade-marker-sell",
          },
          label: {
            borderColor: isBuy ? "#10b981" : "#ef4444",
            offsetY: isBuy ? -12 : 12,
            style: {
              color: "#fff",
              background: isBuy ? "#10b981" : "#ef4444",
              fontSize: "11px",
            },
            text: isBuy ? "BUY" : "SELL",
          },
        };
      });
  }, [trades, asset]);

  useEffect(() => {
    setOptionsState((prev) => ({ ...prev, annotations: { points: tradeAnnotations } }));
  }, [tradeAnnotations]);

  // Recalculate series when toggling EMA
  useEffect(() => {
    if (latestDataRef.current && latestDataRef.current.length) {
      updateChartSeries(latestDataRef.current);
    }
  }, [showEMA, updateChartSeries]);

  // Rotate interval
  const rotateInterval = () => {
    setIntervalState((s) => {
      if (s === 1) return 15;
      if (s === 15) return 30;
      if (s === 30) return 60;
      return 1;
    });
  };

  // ResizeObserver to detect width changes (panel open/close) and handle chart resizing
  useEffect(() => {
    if (!containerRef.current || typeof ResizeObserver === "undefined") {
      // fallback: listen to window resize
      const onWin = () => {
        if (chartRef.current && chartRef.current.chart) {
          try {
            chartRef.current.chart.resize();
          } catch (e) {}
        }
      };
      window.addEventListener("resize", onWin);
      return () => window.removeEventListener("resize", onWin);
    }

    let resizeTimer = null;
    const ro = new ResizeObserver(() => {
      // set resizing flag to temporarily disable animations
      setIsResizing(true);
      setOptionsState(buildBaseOptions(true));
      if (resizeTimer) clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        // after the element stabilizes, re-enable animations and force chart resize
        setIsResizing(false);
        setOptionsState(buildBaseOptions(false));
        try {
          chartRef.current && chartRef.current.chart && chartRef.current.chart.resize();
        } catch (e) {}
      }, 360 + 80); // match panel transition (360ms) + buffer
    });

    ro.observe(containerRef.current);

    return () => {
      if (resizeTimer) clearTimeout(resizeTimer);
      try {
        ro.disconnect();
      } catch (e) {}
    };
  }, [buildBaseOptions]);

  return (
    <div ref={containerRef} className="candlestick-container" style={{ padding: "1rem", background: theme === "dark" ? "transparent" : "#fff", borderRadius: 8 }}>
      <div style={{ marginBottom: "0.75rem", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button onClick={rotateInterval} style={btnStyle}>
            Interval: {interval}m
          </button>
          <button onClick={() => setShowEMA((v) => !v)} style={btnStyle}>
            {showEMA ? "Hide EMA" : "Show EMA"}
          </button>
          <button onClick={() => setTheme((t) => (t === "dark" ? "light" : "dark"))} style={btnStyle}>
            Theme
          </button>
        </div>

        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <div style={{ color: theme === "dark" ? "#cfeffc" : "#555", fontSize: 13 }}>
            Live: {symbol ? "WebSocket" : "Simulated"}
          </div>
        </div>
      </div>

      <Chart ref={chartRef} options={optionsState} series={seriesState} type="candlestick" height={420} />

      <div style={{ marginTop: "1rem", borderTop: "1px solid rgba(255,255,255,0.04)", paddingTop: "0.75rem" }}>
        <h4 style={{ margin: "0 0 8px 0", color: theme === "dark" ? "#cfeffc" : "#333" }}>Chart Settings</h4>
        <p style={{ fontSize: "0.9rem", color: theme === "dark" ? "#cfeffc" : "#555", margin: 0 }}>
          Smooth live updates use Binance WebSocket for 1m interval (BTC/ETH). Zoom/pan are smooth; buy/sell markers are shown on the chart.
        </p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------
   Simple inline style for toolbar buttons
------------------------------------------------------------------- */
const btnStyle = {
  margin: "0 0.5rem 0 0",
  padding: "0.45rem 0.9rem",
  background: "#111827",
  color: "#e6edf3",
  border: "1px solid rgba(255,255,255,0.04)",
  borderRadius: "6px",
  cursor: "pointer",
  fontSize: "0.9rem",
  boxShadow: "0 2px 8px rgba(2,6,23,0.6)",
};

/* ------------------------------------------------------------------
   Helper: fallback series generator
------------------------------------------------------------------- */
function generateFallbackSeries(count = 80, startPrice = 26000) {
  let series = [];
  let lastClose = startPrice;
  for (let i = 0; i < count; i++) {
    const open = lastClose;
    const high = open + Math.random() * (open * 0.01);
    const low = open - Math.random() * (open * 0.01);
    const close = low + Math.random() * (high - low);
    const x = new Date(Date.now() - (count - i) * 60 * 1000);
    series.push({ x, y: [open, high, low, close] });
    lastClose = close;
  }
  return series;
}
