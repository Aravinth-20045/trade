import React, { useMemo } from "react";

/**
 * PortfolioPanel - compact portfolio / allocation side panel
 *
 * Props:
 * - positions: { [asset]: Array<position> }
 * - currentPrices: { [asset]: number }
 *
 * Provides:
 * - Total margin locked
 * - Unrealized PnL
 * - Allocation per asset (notional) with small inline sparkline (based on position amounts)
 *
 * Lightweight, no external deps, memoized for performance.
 */

function tinySparkline(data = [], width = 80, height = 20, stroke = "#3ddcf7") {
  if (!data || data.length === 0) {
    return (
      <svg width={width} height={height}>
        <polyline points="" fill="none" stroke={stroke} strokeWidth="1.5" />
      </svg>
    );
  }
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max === min ? 1 : max - min;
  const step = width / Math.max(1, data.length - 1);
  const points = data
    .map((v, i) => {
      const x = i * step;
      const y = height - ((v - min) / range) * height;
      return `${x},${y}`;
    })
    .join(" ");
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
      <polyline points={points} fill="none" stroke={stroke} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function formatNumber(n) {
  if (n == null || Number.isNaN(n)) return "�";
  if (Math.abs(n) >= 1000) return n.toLocaleString(undefined, { maximumFractionDigits: 2 });
  return Number(n).toFixed(6).replace(/\.?0+$/, "");
}

export default React.memo(function PortfolioPanel({ positions = {}, currentPrices = {} }) {
  const assets = useMemo(() => Object.keys(positions).filter((a) => (positions[a] || []).length > 0), [positions]);

  const summary = useMemo(() => {
    let totalNotional = 0;
    let totalMargin = 0;
    let totalUnrealized = 0;
    const perAsset = [];

    assets.forEach((asset) => {
      const posArr = positions[asset] || [];
      const price = currentPrices[asset] ?? (asset === "sBTC" ? 20000 : asset === "sETH" ? 1500 : 0.02);
      let assetNotional = 0;
      let assetMargin = 0;
      let assetUnrealized = 0;
      const spark = [];

      posArr.forEach((pos) => {
        const notional = pos.amount * pos.entryPrice;
        assetNotional += notional;
        assetMargin += notional / pos.leverage;
        const unrealized = pos.side === "LONG" ? (price - pos.entryPrice) * pos.amount : (pos.entryPrice - price) * pos.amount;
        assetUnrealized += unrealized;
        // add some small synthetic points for sparkline (entryPrice -> current)
        spark.push(pos.entryPrice, price);
      });

      totalNotional += assetNotional;
      totalMargin += assetMargin;
      totalUnrealized += assetUnrealized;

      perAsset.push({
        asset,
        notional: assetNotional,
        margin: assetMargin,
        unrealized: assetUnrealized,
        spark,
      });
    });

    // compute allocation percent
    perAsset.forEach((p) => {
      p.allocation = totalNotional > 0 ? (p.notional / totalNotional) * 100 : 0;
    });

    return { totalNotional, totalMargin, totalUnrealized, perAsset };
  }, [assets, positions, currentPrices]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <div style={{ fontWeight: 800 }}>Portfolio</div>
        <div style={{ fontSize: 12, color: "var(--muted)" }}>{assets.length} assets</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        <div style={{ background: "rgba(255,255,255,0.02)", padding: 10, borderRadius: 8 }}>
          <div style={{ fontSize: 12, color: "var(--muted)" }}>Total Notional</div>
          <div style={{ fontWeight: 800, marginTop: 6 }}>{formatNumber(summary.totalNotional)}</div>
        </div>
        <div style={{ background: "rgba(255,255,255,0.02)", padding: 10, borderRadius: 8 }}>
          <div style={{ fontSize: 12, color: "var(--muted)" }}>Unrealized PnL</div>
          <div style={{ fontWeight: 800, marginTop: 6, color: summary.totalUnrealized >= 0 ? "var(--positive)" : "var(--negative)" }}>
            {summary.totalUnrealized >= 0 ? `+${formatNumber(summary.totalUnrealized)}` : formatNumber(summary.totalUnrealized)}
          </div>
        </div>
      </div>

      <div style={{ fontSize: 13, color: "var(--muted)" }}>Allocation</div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {summary.perAsset.length === 0 ? (
          <div style={{ color: "var(--muted)", fontSize: 13 }}>No assets in portfolio</div>
        ) : (
          summary.perAsset.map((p) => (
            <div key={p.asset} style={{ display: "flex", gap: 10, alignItems: "center", padding: 8, borderRadius: 8, background: "rgba(255,255,255,0.01)" }}>
              <div style={{ width: 56 }}>
                <div style={{ fontWeight: 800 }}>{p.asset}</div>
                <div style={{ fontSize: 12, color: "var(--muted)" }}>{p.allocation.toFixed(1)}%</div>
              </div>

              <div style={{ flex: 1 }}>
                <div style={{ height: 8, background: "rgba(255,255,255,0.03)", borderRadius: 6, overflow: "hidden" }}>
                  <div style={{ width: `${Math.max(1, p.allocation)}%`, height: "100%", background: "linear-gradient(90deg,var(--accent),#00a7d6)" }} />
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "var(--muted)", marginTop: 6 }}>
                  <div>Notional: <span className="mono">{formatNumber(p.notional)}</span></div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    {/* small sparkline */}
                    <div style={{ width: 80, height: 20 }}>{tinySparkline(p.spark, 80, 20)}</div>
                    <div style={{ minWidth: 80, textAlign: "right" }}>{p.unrealized >= 0 ? <span style={{ color: "var(--positive)" }}>+{formatNumber(p.unrealized)}</span> : <span style={{ color: "var(--negative)" }}>{formatNumber(p.unrealized)}</span>}</div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
});